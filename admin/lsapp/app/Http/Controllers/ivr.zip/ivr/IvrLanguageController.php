<?php

namespace App\Http\Controllers\ivr;
use App\Http\Controllers\Controller;

use DB;
use Illuminate\Http\Request;


class IvrLanguageController extends Controller
{
	
		
	public function index($language,$index){
		
		
		$Array['en'] = [
		'handle1' =>'If you have your Telephone Banking login details or ATM Debit Card Number Please Press 1',
		'handle2' =>'To Speak to Customer Care support  Please press 2.',
		'handle3' =>'Please enter your CUSTOMER I D followed by the Pound key',
		'handle4' =>'Your call is being transfered. Please wait while we connect you.',
		'handle5' =>'Hello, Thank you for calling the Customer Care service of',
		'handle6' =>'Please kindly enter The extention number of the department you are trying to reach',
		'handle7' =>"if you doesn't have the extension number, Please stay on the line to be connected to the next available operator",
		'handle8' =>'Please note that this call may be monitored for quality and training purposes',
		'handle9' =>'A Customer Agent will be with you shortly. please hold',
		'handle10' =>'Sorry, I didnt get your CUSTOMER I D',
		'handle11' =>'A Customer representative will be with you shortly. please hold',
		'handle12' => 'Your Input is invalid',
		'handle_map1'=>"if you doesn't have the extension number,  please stay on the line to be connected to the next available operator",
		
		'handle_map'=>"Sorry we can not find the extention Number you entered, please try again with a valid extention number",
		'handle_map2'=>'Kindly enter the Extention Number Again',
		
		'customer_id_login1'=>'Enter your USER I D followed by the Pound key.',
		'customer_id_login2'=>"Sorry, I didn't get your USER I D",
		'customer_id_login3'=>'The CUSTOMER I D is invalid',
		'customer_id_login4'=>'Please re-enter your CUSTOMER I D followed by the Pound key',
		
		'user_id_login1'=>'Please enter your personal SECRET PIN, followed by the Pound key',
		'user_id_login2'=>"Sorry, I didn't get your SECRET PIN.",
		'user_id_login4'=>'The USER I D you enter is invalid.',	
		'user_id_login5'=>'Please re-enter your USER I D, followed by the Pound key',
		
		'pin_login1'=>'Sorry Your Account is blocked  Please Contact Customer Support! Thanks',
		'pin_login2'=>'Welcome back',
		'pin_login3'=>'To check your Account Balance, press 1',
		'pin_login4'=>'For online Transfer requests, press 2',
		'pin_login5'=>'Please press 4 to listen to your last 5 transactions',
		'pin_login6'=>'press 5 to check account status',
		'pin_login7'=>'For checking card status, press 6', //need to add changings
		'pin_login8'=>'To listen your messages, press 3',
		'pin_login10'=>'Please re-enter your PERSONAL SECRET PIN, followed by the Pound key',
		'pin_login11'=>'The SECRET PIN you entered is invalid',
		'pin_login12'=>'You have ',
		'pin_login13'=>'messages in your inbox.',
		
		'Welcome_user2'=>"Sorry, I didn't get your ACCOUNT NUMBER.",
		'Welcome_user3'=>'Please enter your ACCOUNT NUMBER followed by the Pound key.',
		
		'Welcome_user4'=>'To make a local transfer, press 1',
		'Welcome_user5'=>'To make a transfer to another bank, press 2',
		'Welcome_user51'=>'To make a transfer to your own account, press 3', 
		'Welcome_user6'=>'To go back to the MAIN MENU, press the star key',
		
		'Welcome_user7'=>'for credit limit, press 1',

		'Welcome_user8'=>'for credit transfer, press 2',
		'Welcome_user9'=>'To link a credit card account, press 3',
		'Welcome_user10'=>'Go to main menu press star key ',//need to add new
		
		'Welcome_user11'=>'To delete all message, press 2',
		'Welcome_user12'=>'your input is invalid, please enter a valid input',
		'Welcome_user13'=>'To pay Bills online and other special Account feature, press 3',

		'Welcome_user14'=>'To listen to your message number',
		'Welcome_user15'=>'Your status is Pending',
		'Welcome_user16'=>'Your status is Approved',
		'Welcome_user17'=>'Your status is Suspended',
		'Welcome_user18'=>'Your status is Blocked', //need to add new
		'accout_balance_login1'=>'Last Five Transactions  Details for this account',
		'accout_balance_login2'=>'To listen to your Transactions  again press star, To go back to your main Account Menu press 1',
		'accout_balance_login3'=>'Type of Account:',
		'accout_balance_login4'=>'Your Account Balance is',
		'accout_status_suspend1'=>'Status, Your Account is Suspended',
		'accout_status_suspend2'=>'Status, ',
		'accout_status_suspend3'=>'This user profile is currently disabled from accessing this facility, Please visit your nearest branch to  enable this facility in your profile, and allow  you effect transfer to other banks',
		                             
		
		'accout_balance_login5'=>' To listen to your Account balance again press star, To go back to your main Account Menu press 1',
		'accout_balance_login6'=>'The Account Number you entered is invalid',
		'accout_balance_login7'=>'Please re-enter your Account Number',

		'accout_balance_login8'=>'You have entered an invalid Input',
		'transfer_type1'=>'Please note for security reasons, you can only transfer to a saved linked account. and Must be same currency', //need to change
		'transfer_type2'=>'You currently have no saved linked "beneficiary Accounts". Please visit your nearest branch to link a beneficiary account, in other to be able to effect transfer to other banks.',  
		'transfer_type3'=>'To select an Account to make your transfer, press the star key',

		'credit_process1'=>'Your Credit account balance is',
		'credit_process2'=>'To further process please choose from main menu.',
		'credit_process3'=>'You have no credit account linked.',
		'credit_process4'=>'To Link your credit account Please choose from main menu.',
		'credit_process5'=>'In Order to make a transfer the Credit Card must be linked, to listen to the available linked cards press 1',
		'credit_process6'=>'To receive request by mail press 1, To receive request by email press 2',

		'credit_process01'=>'You have the following cards linked,',
		'credit_process02'=>'you have a',
		'credit_process03'=>'Please Enter the last 6 digits on the credit card',
		'credit_process04'=>'This card account belongs to',
		'credit_process05'=>'Please enter amount',
		'credit_process06'=>'You Pushed',
	    'credit_process07'=>'This information entered is not valid, please re enter the 6 digits',
		'credit_process07'=>'Please enter token',
		'credit_process08'=>'Your transfer has been initiated. Give 12 to 24 hours for completion',

		'credit_process001'=>'Amount is greater than your remaining amount please re enter new amount',
		'credit_process002'=>'Request form has been sent to the address on file Thank you',
 	  'credit_process003'=>'Email is not working',
 	  'credit_process004'=>'Request Form has been sent to the email address on file Thank you',

 	  'transfer_acc_amount1'=>'This registered Account details belongs to',
 	  'transfer_acc_amount2'=>'Please enter the Amount to transfer followed by the Pound key.',
 	  'transfer_acc_amount3'=>'The Token Number you entered is invalid.', //need to change
 	  'transfer_acc_amount4'=>'Please re-enter the Routing Number, followed by the Pound key',
 	  
 	  'transfer_token1'=>'Amount Accepted',
 	  'transfer_token2'=>'You have requested to transfer the sum of',
 	
 	 'transfer_token4'=>'Amount not accepted due to insufficient Balance', //need to change new insufficiant speeling is wrong
 	 'transfer_token5'=>'Please Enter a Valid AMOUNT followed by the Pound key',
	 'transfer_token6'=>'Invalid account Number please re enter the account number', //need to add new

 	 'transfer_link_acc1'=>'Your registered linked beneficiary accounts are',  
 	 'transfer_link_accb'=>'Your registered Beneficiary accounts are ', //newadded
 	 'transfer_typeb'=>'Please note for security reasons, you can only transfer to a saved Beneficiary account ', //newadded
 	 'transfer_link_accb1'=>'To Choose this Beneficiary account number ',//newadded
	 
	 
 	  'transfer_link_acc2'=>'To Choose Transfer From Account number', 
	  'transfer_link_acc3'=>' Press ', 
	  'transfer_link_acc4'=>'Please enter your Beneficiary Account number followed by the Pound key. ', 
	  'transfer_link_acc5'=>'To Choose Transfer To Account number', 

      'transfer_link_acc6'=>'Beneficiary Account number is invalid', 
      'transfer_link_acc7'=>'Beneficiary User is suspended', 
      'transfer_link_acc8'=>"Beneficiary User isn\'t approved yet.",
      'transfer_link_acc9'=>'Beneficiary Account Currency does not match Debit Account Currency', 
      'transfer_link_acc10'=>'Please enter your ', 
      'transfer_link_acc11'=>'You entered is invalid', 
	  'transfer_link_acc12'=>'Please Note that a transaction charge of 0.002% is applicable to this transfer', //need to add new
	  'transfer_link_acc13'=>'We will be deducting this charges from the selected account number, please press 1 to countinue ', // newadded
	 
	 
 	  'transfer_acc_sort1'=>'Enter the Routing Number, followed by the Pound key',
 	  'transfer_acc_sort2'=>"Sorry, I didn't get the Routing Number.",
	 
	 
 	  'transfer_acc_sort3'=>"This Account Number is not linked for transfer.",
 	  'transfer_acc_sort4'=>"Please re-enter a registered linked Account Number, followed by the Pound key",		
 	  'transfer_credit1'=>"To go back to the main menu, press 1",
	  'transfer_credit2'=>"To exit, Please hang-up. Thank you.",
	 
	  'transfer_credit3'=>", your transfer request has been accepted",
	  'transfer_credit4'=>"Amount has been debited from your Account.",
	  'transfer_credit5'=>"Your new account balance is",
	  'transfer_credit6'=>"Please allow about 1 to 2 business days for transfered funds to reach beneficiary account.",
	   
	   
	   
	   'transfer_credit7'=>"You have entered an invalid Transfer Token code.",
	   'transfer_credit8'=>'Please Enter your 5 digit "SECRET TRANSFER TOKEN CODE" followed by the Pound key.',
 
	   'transfer_credit9'=>"Sorry, I didn't get your TRANSFER TOKEN CODE",
		'dontGetResponse' => "Sorry, I didn't get your response",
		'ExceedLimit' => "You have exceeded your time-out limit. Good Bye.",

		];
		
		$Array['es'] = [
		'handle1' =>'Si tiene los datos de inicio de sesión de Telephone Bank o el número de tarjeta de débito de ATM, presione 1.',
		'handle2' =>'Para hablar con el servicio de atención al cliente, presione 2.',
		'handle3' =>'Ingrese su ID de CLIENTE seguido de la tecla numeral',
		'handle4' => 'Su llamada está siendo transferida. Espere mientras lo conecto.',
		'handle5' =>'Hola, Gracias por llamar al servicio de Atención al Cliente de',
		'handle6' =>'Por favor, ingrese el número de extensión del departamento al que está tratando de comunicarse',
		'handle7' =>"Si no tiene el número de extensión, permanezca en la línea para conectarse con el siguiente operador disponible.",
		'handle8' =>'Tenga en cuenta que esta llamada puede ser monitoreada por motivos de calidad y capacitación.',
		'handle9' =>'Un agente del cliente estará con usted en breve. por favor espera',
		'handle10' =>'Lo siento, no obtuve su ID DE CLIENTE',
		'handle11' =>'Un representante del cliente estará con usted en breve. por favor espera',
		'handle12' => 'Tu entrada no es válida',
		'handle_map1'=>"Si no tiene extensión, permanezca en la línea para conectarse con el siguiente operador disponible.",
		
		'handle_map'=>"Lo sentimos, no podemos encontrar el número de extensión que ingresó. Vuelva a intentarlo con un número de extensión válido.",
		'handle_map2'=>'Por favor ingrese el número de extensión nuevamente',
		
		'customer_id_login1'=>'Ingrese su USUARIO I D seguida de la tecla Pound.',
		'customer_id_login2'=>"Lo siento, no obtuve tu USER I D",
		'customer_id_login3'=>'La CLIENTE I D no es válida',
		'customer_id_login4'=>'Vuelva a ingresar su ID de CLIENTE seguido de la tecla numeral',
		
		'user_id_login1'=>'Ingrese su PIN SECRETO personal, seguido de la tecla numeral',
		'user_id_login2'=>"Lo siento, no recibí tu PIN SECRETO.",
		'user_id_login4'=>'El ID DE USUARIO que ingresa no es válido.',	
		'user_id_login5'=>'Vuelva a ingresar su ID DE USUARIO, seguido de la tecla de almohadilla',
		
		'pin_login1'=>'Lo sentimos, su cuenta está bloqueada. Póngase en contacto con el servicio de atención al cliente. Gracias',
		'pin_login2'=>'Dar una buena acogida',
		'pin_login3'=>'Para verificar el saldo de su cuenta, presione 1',
		'pin_login4'=>'Para solicitudes de transferencia en línea, presione 2',
		'pin_login5'=>'presione 4 para escuchar sus últimas 5 transacciones',
		'pin_login6'=>'presione 5 para verificar el estado de la cuenta',
		'pin_login7'=>'Para verificar el estado de la tarjeta, presione 6',
		'pin_login8'=>'Para escuchar sus mensajes, presione 3',
		'pin_login10'=>'Vuelva a ingresar su PIN SECRETO PERSONAL, seguido de la tecla numeral',
		'pin_login11'=>'El PIN SECRETO que ingresaste no es válido',
		'pin_login12'=>'Tienes',
		'pin_login13'=>'mensajes en su bandeja de entrada.',
		
		'Welcome_user2'=>"Lo siento, no obtuve su NÚMERO DE CUENTA.",
		'Welcome_user3'=>'Ingrese su NÚMERO DE CUENTA seguido de la tecla numeral.',
		'Welcome_user4'=>'Para hacer una transferencia local, presione 1',
		'Welcome_user5'=>'Para realizar una transferencia a otro banco, presione 2',
		'Welcome_user51'=>'Para hacer una transferencia a una cuenta propia presione 3',
		'Welcome_user6'=>'Para volver al MENÚ PRINCIPAL, presione la tecla asterisco',
		'Welcome_user7'=>'para límite de crédito, presione 1',
		'Welcome_user8'=>'para transferencia de crédito, presione 2',
		'Welcome_user9'=>'Para vincular una cuenta de tarjeta de crédito, presione 3',
		'Welcome_user10'=>'Ir al menú principal presione la tecla asterisco',
		'Welcome_user11'=>'Para borrar todos los mensajes, presione 2',
		'Welcome_user12'=>'su entrada no es válida, por favor ingrese una entrada válida',
		'Welcome_user13'=>'Para pagar facturas en línea y otras funciones especiales de la cuenta, presione 3',
		'Welcome_user14'=>'escuchas el número de mensaje',
		'Welcome_user15'=>'Tu estado es Pendiente',
		'Welcome_user16'=>'Tu estado es Aprobada',
		'Welcome_user17'=>'Tu estado es Suspendida',
		'Welcome_user18'=>'Tu estado es Obstruida',

		'accout_balance_login1'=>'Detalles de las últimas cinco transacciones para esta cuenta',
		'accout_balance_login2'=>'Para escuchar sus Transacciones nuevamente, presione asterisco Para volver al menú principal de su cuenta presione 1',
		'accout_balance_login3'=>' Tipo de cuenta:',
		'accout_balance_login4'=>'El saldo de su cuenta es',
		'accout_balance_login5'=>'Para volver a escuchar el saldo de su cuenta, presione asterisco. Para volver al menú principal de su cuenta, presione 1.',
		'accout_balance_login6'=>'El número de cuenta que ingresó no es válido',
		'accout_balance_login7'=>'Vuelva a ingresar su número de cuenta',

		'transfer_type1'=>'Tenga en cuenta que, por razones de seguridad, solo puede transferir a una cuenta vinculada guardada. emparejado con la misma moneda',
		'transfer_type2'=>'Actualmente no tiene "cuentas locales" vinculadas guardadas. Visite la sucursal más cercana para vincular una cuenta y realizar una transferencia local.',  
		'transfer_type3'=>'Para seleccionar una cuenta para hacer su transferencia, presione la tecla asterisco',

		'credit_process1'=>'El saldo de su cuenta de crédito es',
		'credit_process2'=>'Para continuar con el proceso, elija del menú principal.',
		'credit_process3'=>'No tiene ninguna cuenta de crédito vinculada.',
		'credit_process4'=>'Para vincular su cuenta de crédito, elija del menú principal.',
		'credit_process5'=>'Para realizar una transferencia, la Tarjeta de Crédito debe estar vinculada, para escuchar las tarjetas vinculadas disponibles presione 1',
		'credit_process6'=>'Para recibir la solicitud por correo, presione 1, Para recibir la solicitud por correo electrónico, presione 2',

		'credit_process01'=>'Tienes las siguientes tarjetas vinculadas,',
		'credit_process02'=>'usted tiene un',
		'credit_process03'=>'Ingrese los últimos 6 dígitos de la tarjeta de crédito',
		'credit_process04'=>'Esta cuenta de tarjeta pertenece a',
		'credit_process05'=>'Por favor ingrese la cantidad',
		'credit_process06'=>'Empujaste',
	    'credit_process07'=>'Esta información ingresada no es válida, vuelva a ingresar los 6 dígitos',
		'credit_process07'=>'Por favor ingrese el token',
		'credit_process08'=>'Se ha iniciado tu transferencia. Dar de 12 a 24 horas para completar',

		'credit_process001'=>'El monto es mayor que el monto restante, vuelva a ingresar el nuevo monto',
		'credit_process002'=>'El formulario de solicitud ha sido enviado a la dirección registrada Gracias',
 	  'credit_process003'=>'El correo electrónico no funciona',
 	  'credit_process004'=>'El formulario de solicitud ha sido enviado a la dirección de correo electrónico registrada Gracias',

 	  'transfer_acc_amount1'=>'Los datos de esta cuenta registrada pertenecen a',
 	  'transfer_acc_amount2'=>'Ingrese el monto a transferir seguido de la tecla numeral.',
 	  'transfer_acc_amount3'=>'El número de token que ingresó no es válido.', 
 	  	
 	  'transfer_acc_amount4'=>'Vuelva a ingresar el número de ruta, seguido de la tecla numeral',
 	  
 	  'transfer_token1'=>'Cantidad aceptada',
 	  'transfer_token2'=>'Ha solicitado transferir la suma de',
 	 
 	 'transfer_token4'=>'Importe no aceptado por saldo insuficiente',
 	 'transfer_token5'=>'Ingrese una CANTIDAD válida seguida de la tecla de almohadilla',
 	 'transfer_token6'=>'Número de cuenta no válido, vuelva a introducir el número de cuenta',
 	 'transfer_link_acc1'=>'Sus cuentas vinculadas registradas son', 
 	 
 	  'transfer_link_accb'=>'Sus cuentas de beneficiarios registrados son ', //newadded
 	 'transfer_typeb'=>'Tenga en cuenta que, por razones de seguridad, solo puede transferir a cuentas de Beneficiario guardadas', //newadded
 	 'transfer_link_accb1'=>'Para elegir este número de beneficiario es ',//newadded

 	  'transfer_link_acc2'=>'Para elegir la transferencia desde el número de cuenta',  
	 'transfer_link_acc3'=>'prensa',  
	 'transfer_link_acc4'=>'Ingrese su número de cuenta de Benificiary seguido de la tecla numeral. ',  
	 'transfer_link_acc5'=>'Para elegir Transferir a número de cuenta',  

	'transfer_link_acc6'=>'El número de cuenta de beneficiario no es válido',  
	'transfer_link_acc7'=>'La usuaria beneficiaria está suspendida',  
	'transfer_link_acc8'=>"El usuario beneficiario aún no está aprobado.",  
	'transfer_link_acc9'=>'La moneda de la cuenta del beneficiario no coincide con la moneda de la cuenta de débito', 
	'transfer_link_acc10'=>'Por favor introduzca su ', 
	'transfer_link_acc11'=>'Enterd inválida', 
    'transfer_link_acc12'=>'Tenga en cuenta que el débito por cargos es del 0.002% de cada transferencia', 
	'transfer_link_acc13'=>'Estamos eligiendo su número de cuenta para los cargos de deducción, presione 1 para continuar',


 	 'transfer_acc_sort1'=>'Ingrese el número de ruta, seguido de la tecla numeral',
 	 'transfer_acc_sort2'=>"Lo siento, no obtuve el número de ruta.",
 	  'transfer_acc_sort3'=>"Este número de cuenta no está vinculado para transferencia.",
 	  'transfer_acc_sort4'=>"Vuelva a ingresar un número de cuenta vinculado registrado, seguido de la tecla numeral",		
 	  'transfer_credit1'=>"Para volver al menú principal, presione 1",
	 'transfer_credit2'=>"Para salir, cuelgue. Gracias.",
	  'transfer_credit3'=>",su solicitud de transferencia ha sido aceptada",
	  'transfer_credit4'=>"La suma de se debitará de su cuenta.",
	  'transfer_credit5'=>"El saldo de su nueva cuenta es",
	   'transfer_credit6'=>"Por favor, espere entre 1 y 2 días hábiles para que su transferencia entre en vigencia.",
	   'transfer_credit7'=>"Ha introducido un código de Token de transferencia no válido.",
	   'transfer_credit8'=>'Ingrese su "CÓDIGO SECRETO DE FICHA DE TRANSFERENCIA" de 5 dígitos seguido de la tecla numeral.',
 
	   'transfer_credit9'=>"Lo siento, no recibí tu CÓDIGO DE TRANSFERENCIA DE TOKEN",
		'dontGetResponse' => 'Lo siento, no me dieron',
		'ExceedLimit' => "Has excedido tu límite de tiempo muerto. Adiós.",
		];
		
		$Array['fr-FR'] = [
		'handle1' =>'Si vous avez vos coordonnées bancaires téléphoniques ou votre numéro de carte de débit ATM, appuyez sur 1',
		'handle2' =>'Pour parler au support client, appuyez sur 2.',
		'handle3' =>'Veuillez saisir votre IDENTITÉ DU CLIENT suivi de la touche Dièse',
		'handle4' =>'Votre appel est en cours de transfert. Veuillez patienter pendant que je vous connecte.',
		'handle5' =>"Bonjour, Merci d'avoir appelé le service client de",
		'handle6' =>"Veuillez entrer le numéro de poste du département que vous essayez d'atteindr",
		'handle7' =>"si vous n'avez pas le numéro de poste, veuillez rester en ligne pour être connecté au prochain opérateur disponible",
		'handle8' =>'Veuillez noter que cet appel peut être surveillé à des fins de qualité et de formation',
		'handle9' => 'Un agent client sera avec vous sous peu. attendez svp',
		'handle10' =>"Désolé, je n'ai pas obtenu votre CLIENT I D",
		'handle11' =>'Un représentant client sera avec vous sous peu. attendez svp',
		'handle12' => 'Votre entrée est invalide',
		'handle_map1'=>"si vous n'avez pas d'extension, veuillez rester en ligne pour vous connecter au prochain opérateur disponible",
		
		'handle_map'=>"Désolé, nous ne trouvons pas le numéro d'extension que vous avez entré, veuillez réessayer avec un numéro d'extension valide",
		'handle_map2'=>'Veuillez saisir à nouveau le numéro de poste',
		
		'customer_id_login1'=>'Entrez votre USER I D suivi de la touche Dièse.',
		'customer_id_login2'=>"Désolé, je n'ai pas obtenu votre USER I D",
		'customer_id_login3'=>'Le CLIENT I D est invalide',
		'customer_id_login4'=>'Veuillez saisir à nouveau votre CLIENT I D suivi de la touche Dièse',
		
		'user_id_login1'=>'Veuillez saisir votre PIN SECRET personnel, suivi de la touche Dièse',
		'user_id_login2'=>"Désolée, je n'ai pas reçu votre NIP SECRET.",
		'user_id_login4'=>"L'UTILISATEUR I D que vous entrez n'est pas valide.",	
		'user_id_login5'=>'Veuillez saisir à nouveau votre USER I D, suivi de la touche Dièse',
		
		'pin_login1'=>'Désolé, votre compte est bloqué Veuillez contacter le service client! Merci',
		'pin_login2'=>'Nous saluons le retour',
		'pin_login3'=>'Pour vérifier le solde de votre compte, appuyez sur 1',
		'pin_login4'=>'Pour les demandes de transfert en ligne, appuyez sur 2',
		'pin_login5'=>'appuyez sur 4 pour écouter vos 5 dernières transactions',
		'pin_login6'=>"appuyez sur 5 pour vérifier l'état du compte",
		
		'pin_login7'=>"Pour vérifier l'état de la carte, appuyez sur 6", 
		'pin_login8'=>'Pour écouter vos messages, appuyez sur 3',
		'pin_login10'=>'Veuillez saisir à nouveau votre NIP PERSONNEL SECRET, suivi de la touche Dièse',
		'pin_login11'=>"Le code PIN SECRET que vous avez entré n'est pas valide",
		'pin_login12'=>'Vous avez ',
		'pin_login13'=>'messages dans votre boîte de réception.',
		
		'Welcome_user2'=>"Désolé, je n'ai pas obtenu votre NUMÉRO DE COMPTE.",
		'Welcome_user3'=>'Veuillez entrer votre NUMÉRO DE COMPTE suivi de la touche dièse.',
		
		'Welcome_user4'=>'Pour effectuer un transfert local, appuyez sur 1',
		'Welcome_user5'=>'Pour effectuer un virement vers une autre banque, appuyez sur 2',
		'Welcome_user51'=>'Pour effectuer un virement vers votre propre compte, appuyez sur 3', 
		'Welcome_user6'=>'Pour revenir au MENU PRINCIPAL, appuyez sur la touche étoile',
		
		'Welcome_user7'=>'pour la limite de crédit, appuyez sur 1',

		'Welcome_user8'=>'pour le virement, appuyez sur 2',
		'Welcome_user9'=>'Pour lier un compte de carte de crédit, appuyez sur 3',
		'Welcome_user10'=>'Aller au menu principal appuyez sur la touche étoile',
		'Welcome_user11'=>'Pour supprimer tous les messages, appuyez sur 2',
		'Welcome_user12'=>"votre entrée n'est pas valide, veuillez entrer une entrée valide",
		'Welcome_user13'=>"Pour payer des factures en ligne et d'autres fonctions spéciales de compte, appuyez sur 3",

		'Welcome_user14'=>'vous écoutez le numéro du message',
		'Welcome_user15'=>'Votre statut est en attente',
		'Welcome_user16'=>'Votre statut est approuvé',
		'Welcome_user17'=>'Votre statut est suspendu',
		'Welcome_user18'=>'Votre statut est bloqué', 
		'accout_balance_login1'=>'Détails des cinq dernières transactions pour votre compte',
		'accout_balance_login2'=>'Pour écouter à nouveau vos transactions, appuyez sur étoile Pour revenir au menu principal de votre compte, appuyez sur 1',
		'accout_balance_login3'=>'Type de compte:',
		'accout_balance_login4'=>'Le solde de votre compte est',
		
		'accout_balance_login5'=>'Pour réécouter le solde de votre compte, appuyez sur étoile Pour revenir au menu principal de votre compte, appuyez sur 1',
		'accout_balance_login6'=>"Le numéro de compte que vous avez entré n'est pas valide",
		'accout_balance_login7'=>'Veuillez saisir à nouveau votre numéro de compte',

		'accout_balance_login8'=>'Vous avez entré une entrée non valide',
		'transfer_type1'=>'Veuillez noter que pour des raisons de sécurité, vous ne pouvez transférer que vers un compte associé enregistré. correspondant à la même devise', 

		'transfer_type2'=>"Vous n'avez actuellement aucun 'Comptes locaux' associés enregistrés. Veuillez visiter votre succursale la plus proche pour lier un compte, pour effectuer un virement local.",  
		'transfer_type3'=>'Pour sélectionner un compte pour effectuer votre transfert, appuyez sur la touche étoile',

		'credit_process1'=>'Le solde de votre compte de crédit est',
		'credit_process2'=>'Pour poursuivre le processus, veuillez choisir dans le menu principal.',
		'credit_process3'=>"Vous n'avez aucun compte de crédit lié.",
		'credit_process4'=>'Pour lier votre compte de crédit Veuillez choisir dans le menu principal.',
		'credit_process5'=>'Pour effectuer un virement, la carte de crédit doit être liée, pour écouter les cartes liées disponibles, appuyez sur 1',
		'credit_process6'=>'Pour recevoir une demande par e-mail, appuyez sur 1, Pour recevoir une demande par e-mail, appuyez sur 2',

		'credit_process01'=>'Vous avez les cartes suivantes liées,',
		'credit_process02'=>'tu as un',
		'credit_process03'=>'Veuillez saisir les 6 derniers chiffres de la carte de crédit',
		'credit_process04'=>'Ce compte de carte appartient à',
		'credit_process05'=>'Veuillez saisir le montant',
		'credit_process06'=>'Vous avez poussé',
	    'credit_process07'=>'Ces informations saisies ne sont pas valides, veuillez saisir à nouveau les 6 chiffres',
		'credit_process07'=>'Veuillez saisir le jeton',
		'credit_process08'=>'Votre transfert a été initié. Donnez 12 à 24 heures pour terminer',

		'credit_process001'=>'Le montant est supérieur au montant restant, veuillez saisir à nouveau le nouveau montant',
		'credit_process002'=>"Le formulaire de demande a été envoyé à l'adresse enregistrée Merci",
 	  'credit_process003'=>"L'e-mail ne fonctionne pas",
 	  'credit_process004'=>"Le formulaire de demande a été envoyé à l'adresse e-mail dans le fichier Merci",

 	  'transfer_acc_amount1'=>'Les détails de ce compte enregistré appartiennent à',
 	  'transfer_acc_amount2'=>'Veuillez entrer le montant à transférer suivi de la touche Dièse.',
 	  
 	  'transfer_acc_amount3'=>"Le numéro de jeton que vous avez entré n'est pas valide.", 
 	  'transfer_acc_amount4'=>'Veuillez saisir à nouveau le numéro de routage, suivi de la touche dièse',
 	  
 	  'transfer_token1'=>'Montant accepté',
 	  'transfer_token2'=>'Vous avez demandé le transfert de la somme de',
 	 'transfer_token4'=>"Montant non accepté en raison d'un solde insuffisant",
 	 'transfer_token5'=>'Veuillez saisir un montant valide suivi de la touche dièse',
 	'transfer_token6'=>'Numéro de compte non valide, veuillez saisir à nouveau le numéro de compte',
     'transfer_link_acc1'=>'Vos comptes liés enregistrés sont',
     'transfer_link_accb'=>'Vos comptes de Bénéficiaires enregistrés sont ', //newadded
 	 'transfer_typeb'=>'Veuillez noter que pour des raisons de sécurité, vous ne pouvez transférer que vers un compte de bénéficiaire enregistré ', //newadded
 	 'transfer_link_accb1'=>'Pour Choisir ce Numéro de Bénéficiaire est ',//newadded
	
	 
 	 'transfer_link_acc2'=>'Pour choisir le transfert depuis le numéro de compte', 
	 'transfer_link_acc3'=>'presse', 
	 'transfer_link_acc4'=>'Veuillez saisir votre numéro de compte de bénéficiaire suivi de la touche Dièse.', 
	 'transfer_link_acc5'=>'Pour choisir le transfert vers le numéro de compte', 
	 'transfer_link_acc6'=>"Le numéro de compte du bénéficiaire n'est pas valide", 
	 'transfer_link_acc7'=>"L'utilisateur bénéficiaire est suspendu", 
	 'transfer_link_acc8'=>"L’utilisateur bénéficiaire n’est pas encore approuvé.", 
	 'transfer_link_acc9'=>'La devise du compte du bénéficiaire ne correspond pas à la devise du compte de débit', 
	 'transfer_link_acc10'=>"S'il vous plait entrez votre", 
	'transfer_link_acc11'=>'Vous avez entré invalide', 
		'transfer_link_acc12'=>'Veuillez noter que le débit pour les frais est de 0.002% de chaque transfert', 
		
		'transfer_link_acc13'=>'Nous choisissons votre numéro de compte pour les frais de déduction, veuillez appuyer sur 1 pour continuer ', // newadded
 	 'transfer_acc_sort1'=>"Entrez le numéro d'acheminement, suivi de la touche dièse",
 	 'transfer_acc_sort2'=>"Pardon, je n'ai pas obtenu le numéro de routage.",
 	  'transfer_acc_sort3'=>"Ce numéro de compte n'est pas lié pour le transfert.",
 	  'transfer_acc_sort4'=>"Veuillez saisir à nouveau un numéro de compte lié enregistré, suivi de la touche dièse",		
 	  'transfer_credit1'=>"Pour revenir au menu principal, appuyez sur 1",
	 'transfer_credit2'=>"Pour quitter, veuillez raccrocher. Je vous remercie.",
	  'transfer_credit3'=>", votre demande de transfert a été acceptée à",
	  'transfer_credit4'=>"La somme de sera débitée de votre compte.",
	  'transfer_credit5'=>"Le solde de votre nouveau compte est",
	   'transfer_credit6'=>"Veuillez prévoir environ 1 à 2 jours ouvrables pour que votre transfert prenne pleinement effet.",
	   'transfer_credit7'=>"Vous avez entré un code de jeton de transfert non valide.",
	   'transfer_credit8'=>'Veuillez entrer votre "CODE DE JETON DE TRANSFERT SECRET" à 5 chiffres suivi de la touche dièse.',
 
	   'transfer_credit9'=>"Désolé, je n'ai pas reçu votre CODE DE JETON DE TRANSFERT",
		'dontGetResponse' => "Désolé, je n'ai pas reçu votre réponse",
		'ExceedLimit' => "Vous avez dépassé votre délai d'expiration. Au revoir.",
		];
		
		$Array['de-DE'] = [
		'handle1' =>'Wenn Sie Ihre Anmeldedaten für die Telefonbank oder Ihre ATM-Debitkartennummer haben, drücken Sie 1',
		'handle2' =>'Um mit dem Kundendienst zu sprechen, drücken Sie 2.',
		'handle3' =>'Bitte geben Sie Ihren KUNDEN I D gefolgt von der Pfund-Taste ein',
		'handle4' =>'Ihr Anruf wird weitergeleitet. Bitte warten Sie, während ich Sie verbinde.',
		'handle5' =>'Hallo, vielen Dank, dass Sie den Kundendienst von angerufen haben',
		'handle6' =>'Bitte geben Sie die Durchwahlnummer der Abteilung ein, die Sie erreichen möchten',
		'handle7' =>"Wenn Sie die Nebenstellennummer nicht haben, bleiben Sie in der Leitung, um mit dem nächsten verfügbaren Betreiber verbunden zu werden",
		'handle8' =>'Bitte beachten Sie, dass dieser Anruf zu Qualitäts- und Schulungszwecken überwacht werden kann',
		'handle9' =>'Ein Kundenagent wird in Kürze bei Ihnen sein. bitte halten',
		'handle10' =>'Entschuldigung, ich habe Ihren KUNDEN I D nicht bekommen',
		'handle11' =>'Ein Kundenvertreter wird in Kürze bei Ihnen sein. bitte halten',
		'handle12' => 'Ihre Eingabe ist ungültig',
		'handle_map1'=>"Wenn Sie keine Nebenstelle haben, bleiben Sie bitte in der Leitung, um mit dem nächsten verfügbaren Betreiber verbunden zu werden",
		
		'handle_map'=>"Leider können wir die von Ihnen eingegebene Durchwahlnummer nicht finden. Bitte versuchen Sie es erneut mit einer gültigen Durchwahlnummer",
		'handle_map2'=>'Bitte geben Sie die Nebenstellennummer erneut ein',
		
		'customer_id_login1'=>'Geben Sie Ihren USER I D gefolgt von der Pound-Taste ein.',
		'customer_id_login2'=>"Entschuldigung, ich habe Ihren USER I D nicht bekommen",
		'customer_id_login3'=>'Der CUSTOMER I D ist ungültig',
		'customer_id_login4'=>'Bitte geben Sie Ihren KUNDEN ID erneut ein, gefolgt von der Pfund-Taste',
		
		'user_id_login1'=>'Bitte geben Sie Ihre persönliche SECRET PIN ein, gefolgt von der Pound-Taste',
		'user_id_login2'=>"Entschuldigung, ich habe Ihre SECRET PIN nicht erhalten.",
		'user_id_login4'=>'Der von Ihnen eingegebene USER I D ist ungültig.',	
		'user_id_login5'=>'Bitte geben Sie Ihren USER I D erneut ein, gefolgt von der Pfund-Taste',
		
		'pin_login1'=>'Entschuldigung, Ihr Konto ist gesperrt. Bitte wenden Sie sich an den Kundendienst! Vielen Dank',
		'pin_login2'=>'Willkommen zurück',
		'pin_login3'=>'Drücken Sie 1, um Ihren Kontostand zu überprüfen',
		'pin_login4'=>'Für Online-Überweisungsanfragen drücken Sie 2',
		'pin_login5'=>'Drücken Sie 4, um Ihre letzten 5 Transaktionen anzuhören',
		'pin_login6'=>'Drücken Sie 5, um den Kontostatus zu überprüfen',
		'pin_login7'=>'Drücken Sie 6, um den Kartenstatus zu überprüfen',
		'pin_login8'=>'Drücken Sie 3, um Ihre Nachrichten abzuhören',
		'pin_login10'=>'Bitte geben Sie Ihre PERSONAL SECRET PIN erneut ein, gefolgt von der Pound-Taste',
		'pin_login11'=>'Die von Ihnen eingegebene SECRET PIN ist ungültig',
		'pin_login12'=>'Du hast ',
		'pin_login13'=>'Nachrichten in Ihrem Posteingang.',
		
		'Welcome_user2'=>"Entschuldigung, ich habe Ihre KONTO-NUMMER nicht erhalten.",
		'Welcome_user3'=>'Bitte geben Sie Ihre KONTO-NUMMER gefolgt von der Pfund-Taste ein.',
		
		'Welcome_user4'=>'Um eine lokale Übertragung durchzuführen, drücken Sie 1',
		'Welcome_user5'=>'Um eine Überweisung an eine andere Bank vorzunehmen, drücken Sie 2',
		'Welcome_user51'=>'Um eine Überweisung auf ein eigenes Konto vorzunehmen, drücken Sie 3',
		'Welcome_user6'=>'Drücken Sie die Sterntaste, um zum HAUPTMENÜ zurückzukehren',
		
		'Welcome_user7'=>'Für das Kreditlimit drücken Sie 1',

		'Welcome_user8'=>'Für die Überweisung drücken Sie 2',
		'Welcome_user9'=>'Um ein Kreditkartenkonto zu verknüpfen, drücken Sie 3',
				
		'Welcome_user10'=>'Zum Hauptmenü gehen Sternentaste drücken',
		'Welcome_user11'=>'Um alle Nachrichten zu löschen, drücken Sie 2',
		'Welcome_user12'=>'Ihre Eingabe ist ungültig, bitte geben Sie eine gültige Eingabe ein',
		'Welcome_user13'=>'Drücken Sie 3, um Rechnungen online und andere spezielle Kontofunktionen zu bezahlen',

		'Welcome_user14'=>'Sie hören Nachrichtennummer',
		'Welcome_user15'=>'Ihr Status ist Ausstehend',
		'Welcome_user16'=>'Ihr Status ist Genehmigt',
		'Welcome_user17'=>'Ihr Status ist ausgesetzt',
		'Welcome_user18'=>'Ihr Status ist blockiert', 
		'accout_balance_login1'=>'Letzte fünf Transaktionen Details dazu Ihr Konto',
		'accout_balance_login2'=>'Um Ihre Transaktionen erneut anzuhören, drücken Sie Stern. Um zu Ihrem Hauptkonto-Menü zurückzukehren, drücken Sie 1',
		'accout_balance_login3'=>'Art von Account:',
		'accout_balance_login4'=>'Ihr Kontostand ist',
		'accout_balance_login5'=>'Um Ihren Kontostand erneut anzuhören, drücken Sie Stern. Um zum Hauptkonto-Menü zurückzukehren, drücken Sie 1',
		'accout_balance_login6'=>'Die von Ihnen eingegebene Kontonummer ist ungültig',
		'accout_balance_login7'=>'Bitte geben Sie Ihre Kontonummer erneut ein',

		'accout_balance_login8'=>'Sie haben eine ungültige Eingabe eingegeben',
	'transfer_type1'=>'Bitte beachten Sie aus Sicherheitsgründen, dass Sie nur auf ein gespeichertes verknüpftes Konto übertragen können. mit der gleichen Währung abgeglichen', 
		'transfer_type2'=>'Sie haben derzeit keine verknüpften verknüpften "lokalen Konten" gespeichert. Bitte besuchen Sie die nächstgelegene Filiale, um ein Konto zu verknüpfen und eine lokale Überweisung vorzunehmen.',  
		'transfer_type3'=>'Drücken Sie die Sternentaste, um ein Konto für Ihre Überweisung auszuwählen',

		'credit_process1'=>'Ihr Guthaben ist',
		'credit_process2'=>'Zur weiteren Bearbeitung wählen Sie bitte aus dem Hauptmenü.',
		'credit_process3'=>'Sie haben kein Guthabenkonto verknüpft.',
		'credit_process4'=>'So verknüpfen Sie Ihr Guthabenkonto Wählen Sie bitte aus dem Hauptmenü.',
		'credit_process5'=>'Um eine Überweisung vorzunehmen, muss die Kreditkarte verknüpft sein. Um die verfügbaren verknüpften Karten anzuhören, drücken Sie 1',
		'credit_process6'=>'Um eine Anfrage per E-Mail zu erhalten, drücken Sie 1, Um eine Anfrage per E-Mail zu erhalten, drücken Sie 2',

		'credit_process01'=>'Sie haben die folgenden Karten verknüpft,',
		'credit_process02'=>'du hast ein',
		'credit_process03'=>'Bitte geben Sie die letzten 6 Ziffern auf der Kreditkarte ein.',
		'credit_process04'=>'Dieses Kartenkonto gehört zu',
		'credit_process05'=>'Bitte geben Sie den Betrag ein',
		'credit_process06'=>'Du hast gedrückt',
	    'credit_process07'=>'Diese eingegebenen Informationen sind ungültig. Bitte geben Sie die 6 Ziffern erneut ein',
		'credit_process07'=>'Bitte geben Sie den Token ein',
		'credit_process08'=>'Ihre Übertragung wurde eingeleitet. Geben Sie 12 bis 24 Stunden für die Fertigstellung',
		'credit_process001'=>'Der Betrag ist größer als Ihr Restbetrag. Bitte geben Sie den neuen Betrag erneut ein',
		'credit_process002'=>'Das Anfrageformular wurde an die angegebene Adresse gesendet. Vielen Dank',
 	  'credit_process003'=>'E-Mail funktioniert nicht',
 	 'credit_process004'=>'Das Anfrageformular wurde an die in der Datei angegebene E-Mail-Adresse gesendet. Vielen Dank',

 	  'transfer_acc_amount1'=>'Diese registrierten Kontodaten gehören zu',
 	 'transfer_acc_amount2'=>'Bitte geben Sie den zu überweisenden Betrag gefolgt von der Pfund-Taste ein.',
 	 'transfer_acc_amount3'=>'Die von Ihnen eingegebene Token-Nummer ist ungültig.',
 	  'transfer_acc_amount4'=>'Bitte geben Sie die Routing-Nummer erneut ein, gefolgt von der Pfund-Taste',
 	  
 	  'transfer_token1'=>'Akzeptierter Betrag',
 	  'transfer_token2'=>'Sie haben beantragt, die Summe von zu überweisen',
 	 'transfer_token4'=>'Betrag wegen unzureichendem Guthaben nicht akzeptiert', 
 	 'transfer_token5'=>'Bitte geben Sie einen gültigen Betrag gefolgt von der Pfund-Taste ein',
 	'transfer_token6'=>'Ungültige Kontonummer Bitte geben Sie die Kontonummer erneut ein', 
 	'transfer_link_acc1'=>'Ihre registrierten verknüpften Konten sind',  
 	 'transfer_link_accb'=>'Ihre registrierten Begünstigtenkonten sind ', //newadded
 	 'transfer_typeb'=>'Bitte beachten Sie aus Sicherheitsgründen, dass Sie nur auf ein gespeichertes Empfängerkonto überweisen können ', //newadded
 	 'transfer_link_accb1'=>'Um diese Begünstigtennummer zu wählen ist ',//newadded

 	 'transfer_link_acc2'=>'So wählen Sie Übertragung von Kontonummer', 
	 'transfer_link_acc3'=>'Drücken Sie',  
	 'transfer_link_acc4'=>'Bitte geben Sie Ihre Benificiary-Kontonummer gefolgt von der Pfund-Taste ein.', 
	 'transfer_link_acc5'=>'So wählen Sie Übertragung auf Kontonummer',  

	'transfer_link_acc6'=>'Die Nummer des Benificiary-Kontos ist ungültig',  
	'transfer_link_acc7'=>'Der begünstigte Benutzer ist gesperrt',  
	'transfer_link_acc8'=>"Der begünstigte Benutzer ist noch nicht genehmigt.", 
	'transfer_link_acc9'=>'Die Währung des Empfängerkontos stimmt nicht mit der Währung des Lastschriftkontos überein',
	'transfer_link_acc10'=>'Bitte geben Sie Ihre', 
	'transfer_link_acc11'=>'Sie haben ungültig eingegeben', 
	
		'transfer_link_acc12'=>'Bitte beachten Sie, dass die Belastung der Gebühren 0.002% jeder Überweisung beträgt',
			'transfer_link_acc13'=>'Wir wählen Ihre Kontonummer für den Abzug von Gebühren aus. Bitte drücken Sie 1 um fortzufahren', // newadded
		 
 	 'transfer_acc_sort1'=>'Geben Sie die Routing-Nummer gefolgt von der Pfund-Taste ein',
 	 'transfer_acc_sort2'=>"Entschuldigung, ich habe die Routing-Nummer nicht erhalten.",
 	  'transfer_acc_sort3'=>"Diese Kontonummer ist nicht zur Übertragung verknüpft.",
 	  'transfer_acc_sort4'=>"Bitte geben Sie eine registrierte verknüpfte Kontonummer erneut ein, gefolgt von der Pfund-Taste",		
 	  'transfer_credit1'=>"Um zum Hauptmenü zurückzukehren, drücken Sie 1",
	 'transfer_credit2'=>"Zum Verlassen legen Sie bitte auf. Dankeschön.",
	  'transfer_credit3'=>", Ihre Überweisungsanfrage wurde angenommen",
	  'transfer_credit4'=>"Die Summe wird von Ihrem Konto abgebucht.",
	  'transfer_credit5'=>"Ihr neuer Kontostand ist",
	   'transfer_credit6'=>"Bitte erlauben Sie 1 bis 2 Werktage, damit Ihre Überweisung vollständig wirksam wird.",
	   'transfer_credit7'=>"Sie haben einen ungültigen Transfer-Token-Code eingegeben.",
	   'transfer_credit8'=>'Bitte geben Sie Ihren 5-stelligen "SECRET TRANSFER TOKEN CODE" gefolgt von der Pfund-Taste ein.',
 
	   'transfer_credit9'=>"Entschuldigung, ich habe Ihren TRANSFER TOKEN CODE nicht erhalten",
		'dontGetResponse' => "Entschuldigung, ich habe Ihre Antwort nicht erhalten",
		'ExceedLimit' => "Sie haben Ihr Timeout-Limit überschritten. Auf Wiedersehen."
		];
		
		$Array['ja-JP'] = [
		'handle1' =>'Denwa ginkō no roguin jōhō matawa ATM debittokādo bangō o o-mochi no baai wa, 1 o oshite kudasai',
		'handle2' =>'Kasutamākeasapōto ni hanasu ni wa, 2 o oshimasu.',
		'handle3' =>'CUSTOMER ID ni tsudzukete pondokī o nyūryoku shite kudasai',
		'handle4' =>'Tsūwa ga tensō sa rete imasu. Setsuzoku suru made omachikudasai.',
		'handle5' =>"Kon'nichiwa, no kasutamākeasābisu ni o denwa itadaki arigatōgozaimasu",
		'handle6' =>'Tōtatsu shiyou to shite iru bumon no naisen bangō o nyūryoku shite kudasai',
		'handle7' =>"Naisen bangō o o mochi denai baai wa,-ji no riyō kanōna operētā ni setsuzoku suru tame ni kaisen ni todomatte kudasai",
		'handle8' =>'Kono tsūwa wa, hinshitsu to torēningu no mokuteki de kanshi sa reru baai ga aru koto ni chūi shite kudasai',
		'handle9' =>"Kasutamāējento ga mamonaku go an'nai shimasu. Omachikudasai",
		'handle10' =>'Mōshiwakearimasenga, okyakusama no ID o shutoku dekimasendeshita',
		'handle11' =>'Kasutamā tantōsha ga mamonaku anata to issho ni narimasu. Omachikudasai',
		'handle12' => 'Nyūryoku ga mukōdesu',
		'handle_map1'=>"Naisen bangō ga nai baai wa,-ji no riyō kanōna operētā ni setsuzoku suru tame ni kaisen o iji shite kudasai",
		
		'handle_map'=>"Nyūryoku shita kakuchō bangō ga mitsukarimasen. Yūkōna kakuchō bangō de mōichido o tameshi kudasai",
		'handle_map2'=>'Enchō bangō o mōichido nyūryoku shite kudasai',
		
		'customer_id_login1'=>'USER ID ni tsudzukete pondokī o nyūryoku shimasu.',
		'customer_id_login2'=>"Mōshiwakearimasenga, yūzā ID o shutoku dekimasendeshita",
		'customer_id_login3'=>'CUSTOMER ID ga mukōdesu',
		'customer_id_login4'=>'CUSTOMER ID ni tsudzukete pondokī o sai nyūryoku shite kudasai',
		
		'user_id_login1'=>'Anshō bangō o nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
		'user_id_login2'=>"Mōshiwakearimasenga, himitsu no pin o shutoku dekimasendeshita.",
		'user_id_login4'=>'Nyūryoku shita yūzā ID ga mukōdesu.',	
		'user_id_login5'=>'USER I D o sai nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
		
		'pin_login1'=>'Mōshiwakearimasenga, akaunto ga burokkusareteimasu. Kasutamāsapōto ni go renraku kudasai. Arigatō',
		'pin_login2'=>'Okaerinasai',
		'pin_login3'=>'Akaunto no zandaka o kakunin suru ni wa, 1 o oshimasu',
		'pin_login4'=>'Onrain tensō rikuesuto no baai wa, 2 o oshimasu',
		'pin_login5'=>'4 O oshite, saigo no itsutsu no toranzakushon o kikimasu',
		'pin_login6'=>'5 O oshite akaunto no sutētasu o kakunin shimasu',
		'pin_login7'=>'Kādo no jōtai o kakunin suru ni wa, 6 o oshimasu',
		'pin_login8'=>'Messēji o kiku ni wa, 3 o oshimasu',
		'pin_login10'=>'Anshō bangō o sai nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
		'pin_login11'=>'Nyūryoku shita himitsu no pin ga mukōdesu',
		'pin_login12'=>'Anata ga motte iru ',
		'pin_login13'=>'Jushin torei no messēji.',
		
		'Welcome_user2'=>"Mōshiwakearimasenga, akaunto bangō o shutoku dekimasendeshitaNumber.",
		'Welcome_user3'=>'Akaunto bangō ni tsudzukete pondokī o nyūryoku shite kudasai.',
		
		'Welcome_user4'=>'Rōkaru tensō o okonau ni wa, 1 o oshimasu',
		'Welcome_user5'=>'Betsu no ginkō ni sōkin suru ni wa, 2 o oshimasu',
		'Welcome_user51'=>'Jibun no kōza ni sōkin suru ni wa 3 o oshimasu',
		'Welcome_user6'=>'Meinmenyū ni modoru ni wa, sutākī o oshimasu',
		
		'Welcome_user7'=>'Yoshin gendo-gaku ni tsuite wa, 1 o oshite kudasai',

		'Welcome_user8'=>'Kurejitto tensō no baai wa, 2 o oshimasu',
		'Welcome_user9'=>'Kurejittokādoakaunto o rinku suru ni wa, 3 o oshimasu',
		'Welcome_user10'=>'Meinmenyū ni idō shi, sutākī o oshimasu',
		'Welcome_user11'=>'Subete no messēji o sakujo suru ni wa, 2 o oshimasu',
		'Welcome_user12'=>'Nyūryoku ga mukōdesu. Yūkōna nyūryoku o nyūryoku shite kudasai',
		'Welcome_user13'=>'Onrain de seikyū-sho ya sonohoka no tokubetsuna akaunto kinō o shiharau ni wa, 3 o oshimasu',

		'Welcome_user14'=>'Anata wa messēji bangō o kikimasu',
		'Welcome_user15'=>'Anata no sutētasu wa horyū-chūdesu',
		'Welcome_user16'=>'Anata no sutētasu wa shōnin-zumidesu',
		'Welcome_user17'=>'Anata no sutētasu wa ichiji teishi sa rete imasu',
		'Welcome_user18'=>'Anata no sutētasu wa burokkusareteimasu',
		'accout_balance_login1'=>'Kono akaunto no kako 5-kai no torihiki no shōsai',
		'accout_balance_login2'=>'Toranzakushon o mōichido kiku ni wa, sutā o oshimasu. Mein no akauntomenyū ni modoru ni wa, 1 o oshimasu.',
		'accout_balance_login3'=>'Akaunto no taipu:',
		'accout_balance_login4'=>'Akaunto no zandaka wa',
		
		'accout_balance_login5'=>'Akaunto no zandaka o mōichido kiku ni wa, sutā o oshimasu. Mein no akauntomenyū ni modoru ni wa, 1 o oshimasu.',
		'accout_balance_login6'=>'Nyūryoku shita kōza bangō ga mukōdesu',
		'accout_balance_login7'=>'Akaunto bangō o sai nyūryoku shite kudasai',

		'accout_balance_login8'=>'Mukōna nyūryoku o nyūryoku shimashita',
		'transfer_type1'=>'Sekyuriti-jō no riyū kara, hozon sa reta rinku sa reta akaunto ni nomi tensō dekiru koto ni chūi shite kudasai. Onaji tsūka to itchi',
		'transfer_type2'=>"Genzai, rinku sa reta `rōkaruakaunto' wa hozon sa rete imasen. Moyori no shiten ni akusesu shite akaunto o rinku shi, rōkaru tensō o okonatte kudasai.",  
		'transfer_type3'=>'Tensō suru akaunto o sentaku suru ni wa, sutākī o oshimasu',

		'credit_process1'=>'Kurejitto akaunto no zandaka wa',
		'credit_process2'=>'Sarani shori suru ni wa, meinmenyū kara sentaku shite kudasai.',
		'credit_process3'=>'Rinku sa rete iru kurejitto akaunto ga arimasen.',
		'credit_process4'=>'Kurejitto akaunto o rinku suru ni wa meinmenyū kara sentaku shite kudasai.',
		'credit_process5'=>'Tensō o okonau ni wa, kurejittokādo o rinku suru hitsuyō ga arimasu. Riyō kanōna rinku sa reta kādo o kiku ni wa, 1 o oshimasu.',
		'credit_process6'=>'Mērupuresu 1 de rikuesuto o jushin suru ni wa mērupuresu 2 de rikuesuto o jushin suru ni wa',

		'credit_process01'=>'Tsugi no kādo ga rinku sa rete imasu,',
		'credit_process02'=>'Ga arimasu',
		'credit_process03'=>'Kurejittokādo no shita 6-keta o nyūryoku shite kudasai',
		'credit_process04'=>'Kono kādoakaunto wa',
		'credit_process05'=>'Kingaku o nyūryoku shite kudasai',
		'credit_process06'=>'Anata ga oshita',
	    'credit_process07'=>'Nyūryoku shita kono jōhō wa mukōdesu. 6-Keta o sai nyūryoku shite kudasai',
		'credit_process07'=>'Tōkun o nyūryoku shite kudasai',
		'credit_process08'=>'Tensō ga kaishi sa remashita. Kanryō made ni 12 〜 24-jikan o ataemasu',

		'credit_process001'=>'Kingaku ga nokori kingaku o koete iru baai wa, atarashī kingaku o sai nyūryoku shite kudasai',
		'credit_process002'=>'Rikuesutofōmu wa tōroku sa rete iru adoresu ni sōshin sa remashita arigatōgozaimasu',
 	  'credit_process003'=>'Mēru ga kinō shinai',
 	  'credit_process004'=>'Rikuesutofōmu wa tōroku sa rete iru mēruadoresu ni sōshin sa remashita arigatōgozaimasu',

 	  'transfer_acc_amount1'=>'Kono tōroku-zumi akaunto no shōsai wa ni zokushimasu',
 	  'transfer_acc_amount2'=>'Tensō suru kingaku o nyūryoku shite kara, pondokī o nyūryoku shite kudasai.',
 	  'transfer_acc_amount3'=>'Nyūryoku shita tōkun bangō ga mukōdesu.', 
 	  'transfer_acc_amount4'=>'Ginkō kōdo o sai nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
 	  'transfer_token1'=>'Ukeire rareta kingaku',
 	  'transfer_token2'=>'No gōkei o tensō suru yō ni rikuesuto shimashita',
 	'transfer_token4'=>'Zandaka ga fusoku shite iru tame, kingaku wa uketsuke raremasen',
 	 'transfer_token5'=>'Yūkōna kingaku o nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
 	  'transfer_token6'=>'Mukōna akaunto bangō akaunto bangō o sai nyūryoku shite kudasai',
 	 'transfer_link_acc1'=>'Anata no tōroku sa reta rinku sa reta akaunto wa', 
 	 
 	  'transfer_link_accb'=>'Tōroku sa reta uketori hito no akaunto wa ', //newadded
 	 'transfer_typeb'=>'Sekyuriti-jō no riyū kara, hozon sa reta uketori hito no akaunto ni nomi tensō dekiru koto ni chūi shite kudasai ', //newadded
 	 'transfer_link_accb1'=>'Kono uketori hito bangō o sentaku suru ni wa ',//newadded
	
	 'transfer_link_acc2'=>'Akaunto bangō kara no tensō o sentaku suru ni wa',  
	 'transfer_link_acc3'=>'Osu',
	 'transfer_link_acc4'=>'Uketori hito no kōza bangō ni tsudzukete pondokī o nyūryoku shite kudasai.', 
	 'transfer_link_acc5'=>'Akaunto bangō e no tensō o sentaku suru ni wa',

	'transfer_link_acc6'=>'Uketori hito no kōza bangō ga mukōdesu',  
	'transfer_link_acc7'=>'Uketori hito yūzā ga teishi sa remashita',  
	'transfer_link_acc8'=>"Uketori hito yūzā wa mada shōnin sa rete imasen.",  
	'transfer_link_acc9'=>'Uketori hito no kōza tsūka ga Debitto kōza no tsūka to itchi shimasen',
	'transfer_link_acc10'=>'Nyūryoku shite kudasai', 
	'transfer_link_acc11'=>'Mukō o nyūryoku shimashita', 
	'transfer_link_acc12'=>'Ryōkin no hikiotoshi wa, kaku sōkin no 2-pāsentodesu.', 
	'transfer_link_acc13'=>'Kōjo ryōkin no akaunto bangō kara anata o sentaku shite imasu 1 o Osae shite kaunto shite kudasai', // newadded

	 
 	 'transfer_acc_sort1'=>'Ginkō kōdo o nyūryoku shi, tsudzuite pondokī o nyūryoku shimasu',
 	 'transfer_acc_sort2'=>"Mōshiwakearimasenga, ginkō kōdo o shutoku dekimasendeshita.",
 	  'transfer_acc_sort3'=>"Kono akaunto bangō wa tensō-yō ni rinku sa rete imasen.",
 	  'transfer_acc_sort4'=>"Tōroku-zumi no rinku sa reta akaunto bangō o sai nyūryoku shite kara, pondokī o nyūryoku shite kudasai",		
 	  'transfer_credit1'=>"Meinmenyū ni modoru ni wa, 1 o oshimasu.",
	 'transfer_credit2'=>"Shūryō suru ni wa, denwa o kitte kudasai. Arigatōgozaimashita.",
	  'transfer_credit3'=>", Anata no tensō rikuesuto wa ni ukeire raremashita",
	  'transfer_credit4'=>"No gōkei wa anata no akaunto kara hikiotosa remasu.",
	  'transfer_credit5'=>"Atarashī akaunto no zandaka wa",
	   'transfer_credit6'=>"Sōkin ga kanzen ni yūkō ni naru made, yaku 1 〜 2 eigyō-bi kakarimasu.",
	   'transfer_credit7'=>"Mukōna tensō tōkunkōdo o nyūryoku shimashita.",
	   'transfer_credit8'=>"5-Keta no `SECRETTRANSFERTOKEN kode' ni tsudzukete, pondokī o nyūryoku shite kudasai",
 
	   'transfer_credit9'=>"Mōshiwakearimasenga, tensō tōkunkōdo o shutoku dekimasendeshita",
		'dontGetResponse' => "Mōshiwakearimasenga, henshin ga arimasen",
		'ExceedLimit' => "Taimuauto seigen o koemashita. Sayōnara."
		];
		
		$Array['pt'] = [
		'handle1' =>'Se você tiver os detalhes de login do seu banco telefônico ou o número do cartão de débito no caixa eletrônico, pressione 1',
		'handle2' =>'Para falar com o atendimento ao cliente, pressione 2.',
		'handle3' =>'Por favor, insira seu CLIENTE I D seguido da chave de libra',
		'handle4' =>'Sua chamada está sendo transferida. Por favor, espere enquanto eu conecto você.',
		'handle5' =>'Olá, obrigado por ligar para o serviço de atendimento ao cliente de',
		'handle6' =>'Por favor, insira o número da extensão do departamento que você está tentando acessar',
		'handle7' =>"se você não tiver o número do ramal, por favor, fique na linha para ser conectado à próxima operadora disponível",
		'handle8' =>'Observe que esta ligação pode ser monitorada para fins de qualidade e treinamento',
		'handle9' =>'Um agente do cliente estará com você em breve. Por favor, espere',
		'handle10' =>'Desculpe, não recebi seu CLIENTE I D',
		'handle11' =>'Um representante do cliente estará com você em breve. Por favor, espere',
		'handle12' => 'Sua entrada é inválida',
		'handle_map1'=>"se você não tem ramal, por favor, fique na linha para ser conectado à próxima operadora disponível",
		
		'handle_map'=>"Não foi possível encontrar o número da extensão que você inseriu, tente novamente com um número de extensão válido",
		'handle_map2'=>'Digite o número da extensão novamente',
		
		'customer_id_login1'=>'Digite seu USER I D seguido da tecla Libra.',
		'customer_id_login2'=>"Desculpe, não recebi seu USER I D",
		'customer_id_login3'=>'O CUSTOMER I D é inválido',
		'customer_id_login4'=>'Por favor, digite novamente seu CLIENTE I D seguido pela chave de libra',
		
		'user_id_login1'=>'Por favor, digite seu PIN SECRETO pessoal, seguido pela chave Libra',
		'user_id_login2'=>"Não recebi seu PIN SECRETO.",
		'user_id_login4'=>'O USER I D inserido é inválido.',	
		'user_id_login5'=>'Digite novamente o seu USER I D, seguido pela tecla Libra',
		
		'pin_login1'=>'Desculpe, sua conta está bloqueada. Entre em contato com o Suporte ao Cliente! obrigado',
		'pin_login2'=>'Bem vindo de volta',
		'pin_login3'=>'Para verificar o saldo da sua conta, pressione1',
		'pin_login4'=>'Para solicitações de transferência online, pressione 2',
		'pin_login5'=>'pressione 4 para ouvir suas últimas 5 transações',
		'pin_login6'=>'pressione 5 para verificar o status da conta',
		'pin_login7'=>'Para verificar o status do cartão, pressione 6',
		'pin_login8'=>'Para ouvir suas mensagens, pressione 3',
		'pin_login10'=>'Digite novamente seu PIN DE SEGREDO PESSOAL, seguido da chave de libra',
		'pin_login11'=>'O PIN SECRETO inserido é inválido',
		'pin_login12'=>'Você tem ',
		'pin_login13'=>'mensagens em sua caixa de entrada.',
		
		'Welcome_user2'=>"Desculpe, não recebi seu NÚMERO DE CONTA.",
		'Welcome_user3'=>'Por favor, insira seu NÚMERO DE CONTA seguido da chave Libra.',
		
		'Welcome_user4'=>'Para fazer uma transferência local, pressione 1',
		'Welcome_user5'=>'Para fazer uma transferência para outro banco, pressione 2',
		'Welcome_user51'=>'Para fazer uma transferência para sua própria conta, pressione 3',
		'Welcome_user6'=>'Para voltar ao MENU PRINCIPAL, pressione a tecla estrela',
		
		'Welcome_user7'=>'para limite de crédito, pressione 1',

		'Welcome_user8'=>'para transferência de crédito, pressione 2',
		'Welcome_user9'=>'Para vincular uma conta de cartão de crédito, pressione 3',
		'Welcome_user10'=>'Vá para o menu principal pressione a tecla estrela',
		'Welcome_user11'=>'Para excluir todas as mensagens, pressione 2',
		'Welcome_user12'=>'sua entrada é inválida, insira uma entrada válida',
	'Welcome_user13'=>'Para pagar contas online e outro recurso especial da conta, pressione 3',

		'Welcome_user14'=>'você escuta o número da mensagem',
		'Welcome_user15'=>'Seu status está pendente',
		'Welcome_user16'=>'Seu status é aprovado',
		'Welcome_user17'=>'Seu status está suspenso',
		'Welcome_user18'=>'Seu status é Bloqueado',
		'accout_balance_login1'=>'Detalhes das últimas cinco transações para esta sua conta',
		'accout_balance_login2'=>'Para ouvir suas transações novamente, pressione estrela. Para voltar ao menu principal da conta, pressione 1',
		'accout_balance_login3'=>'Tipo de conta:',
		'accout_balance_login4'=>'O saldo da sua conta é',
		
		'accout_balance_login5'=>'Para ouvir o saldo da sua conta novamente, pressione estrela. Para voltar ao menu principal da conta, pressione 1',
		'accout_balance_login6'=>'O número da conta que você inseriu é inválidod',
		'accout_balance_login7'=>'Digite novamente o seu número de conta',

		'accout_balance_login8'=>'Você inseriu uma entrada inválida',
		'transfer_type1'=>'Observe que, por razões de segurança, você só pode transferir para uma conta vinculada salva. combinado com a mesma moeda',
		'transfer_type2'=>'No momento, você não tem "Contas locais" vinculadas salvas. Visite a filial mais próxima para vincular uma conta e fazer uma transferência local.',  
		'transfer_type3'=>'Para selecionar uma conta para fazer sua transferência, pressione a tecla estrela',

		'credit_process1'=>'O saldo de sua conta de crédito é',
		'credit_process2'=>'Para continuar o processo, escolha no menu principal.',
		'credit_process3'=>'Você não tem nenhuma conta de crédito vinculada.',
		'credit_process4'=>'Para vincular sua conta de crédito Escolha no menu principal.',
		'credit_process5'=>'Para fazer uma transferência, o cartão de crédito deve estar vinculado; para ouvir os cartões vinculados disponíveis, pressione 1',
		'credit_process6'=>'Para receber um pedido por e-mail, pressione 1, Para receber um pedido por e-mail, pressione 2',

		'credit_process01'=>'Você tem os seguintes cartões vinculados,',
		'credit_process02'=>'você tem um',
		'credit_process03'=>'Insira os últimos 6 dígitos do cartão de crédito',
		'credit_process04'=>'Esta conta de cartão pertence a',
		'credit_process05'=>'Por favor, insira o valor',
		'credit_process06'=>'Você empurrou',
	    'credit_process07'=>'Esta informação inserida não é válida, por favor insira novamente os 6 dígitos',
		'credit_process07'=>'Por favor, insira o token',
		'credit_process08'=>'Sua transferência foi iniciada. Dê 12 a 24 horas para a conclusão',

		'credit_process001'=>'O valor é maior do que o valor restante, insira novamente o novo valor',
		'credit_process002'=>'O formulário de solicitação foi enviado para o endereço registrado. Obrigado',
 	  'credit_process003'=>'Email não está funcionando',
 	  'credit_process004'=>'O formulário de solicitação foi enviado para o endereço de e-mail registrado. Obrigado',

 	  'transfer_acc_amount1'=>'Os detalhes desta conta registrada pertencem a',
 	  'transfer_acc_amount2'=>'Por favor, insira o valor a ser transferido seguido da tecla Libra.',
 	  'transfer_acc_amount3'=>'O número do token inserido é inválido.',  
 	  'transfer_acc_amount4'=>'Digite novamente o número de roteamento, seguido da tecla Libra',
 	  'transfer_link_acc1'=>'Suas contas vinculadas registradas são',  
 	  
 	   'transfer_link_accb'=>'Suas contas de beneficiário registradas são ', //newadded
 	 'transfer_typeb'=>'Observe que, por razões de segurança, você só pode transferir para contas salvas de beneficiário ', //newadded
 	 'transfer_link_accb1'=>'Para escolher este número de beneficiário é ',//newadded
	 
	 
 	 'transfer_link_acc2'=>'Para escolher o número de transferência da conta',  
	 'transfer_link_acc3'=>'pressione',  
	 'transfer_link_acc4'=>'Insira o número da sua conta de beneficiário seguido da chave Libra.',
	 'transfer_link_acc5'=>'Para escolher o número de transferência para conta',
	'transfer_link_acc6'=>'O número da conta do beneficiário é inválido', 
	'transfer_link_acc7'=>'O usuário beneficiário está suspenso',  
	'transfer_link_acc8'=>"O usuário beneficiário ainda não foi aprovado.",
	'transfer_link_acc9'=>'A moeda da conta do beneficiário não corresponde à moeda da conta de débito', 
	'transfer_link_acc10'=>'Por favor insira o seu',
	'transfer_link_acc11'=>'Você digitou inválido', 
	
		'transfer_link_acc12'=>'Observe que o débito para despesas é de 0.002% de cada transferência',
		
		'transfer_link_acc13'=>'Estamos escolhendo o seu número de conta para despesas de dedução, pressione 1 para continuar ', // newadded

 	  'transfer_token1'=>'Quantia Aceita',
 	  'transfer_token2'=>'Você solicitou a transferência da soma de',
 	 'transfer_token4'=>'Quantidade não aceita devido a saldo insuficiente',
 	 'transfer_token5'=>'Insira um VALOR válido seguido da chave de libra',
 	  'transfer_token6'=>'Número de conta inválido, digite novamente o número da conta', 
 	 'transfer_acc_sort1'=>'Digite o número de roteamento, seguido pela tecla Libra',
 	 'transfer_acc_sort2'=>"Desculpe, não recebi o número de roteamento.",
 	  'transfer_acc_sort3'=>"Este número de conta não está vinculado à transferência.",
 	  'transfer_acc_sort4'=>"Digite novamente um número de conta registrado vinculado, seguido da chave Libra",		
 	  'transfer_credit1'=>"Para voltar ao menu principal, pressione 1",
	 'transfer_credit2'=>"Para sair, desligue. Obrigado.",
	  'transfer_credit3'=>", sua solicitação de transferência foi aceita to",
	  'transfer_credit4'=>"A soma de será debitada de sua conta.",
	  'transfer_credit5'=>"O novo saldo da sua conta é",
	   'transfer_credit6'=>"Por favor, aguarde cerca de 1 a 2 dias úteis para que sua transferência tenha efeito total.",
	   'transfer_credit7'=>"Você inseriu um código de Token de transferência inválido.",
	   'transfer_credit8'=>'Digite seu "CÓDIGO DE TOKEN DE TRANSFERÊNCIA SECRETA" de 5 dígitos seguido da tecla Libra.',
 
	   'transfer_credit9'=>"Lamento, mas não recebi o seu CÓDIGO DO TOKEN DE TRANSFERÊNCIA",
		'dontGetResponse' => "Desculpe, não recebi sua resposta",
		'ExceedLimit' => "Você excedeu o seu limite de tempo. Tchau."
		];
		
		$Array['ar'] = [
		'handle1' =>"iidha kanat ladayk tafasil tasjil aldukhul 'iilaa albank alhatifii 'aw raqm bitaqat alkhasm min ATM , fadght 1",
		'handle2' =>"liltahaduth 'iilaa daem khidmat aleumla' , adghut 2.",
		'handle3' =>'alraja iidkhal aleamyl I D alkhasu bik mtbweana bimiftah aljunayh',
		'handle4' =>"ytm tahwil mukalamtak. yrja alaintizar hataa 'aqwam bitawsilik.",
		'handle5' =>"mrhbana , shkrana lak ealaa aitisalik bikhidmat aleumla' fi",
		'handle6' =>"yrja altakarum bi'iidkhal alraqm alddakhilii lilqism aldhy tuhawil alwusul 'iilayh",
		'handle7' =>"'iidha lm yakun ladayk alraqm alddakhilii , falrija' albaqa' ealaa alkhati lilaitisal bialmashghal alttali almatah",
		'handle8' =>"yrja mulahazatan 'anah qad yatimu muraqabat hadhih almukalamat li'aghrad aljawdat waltadrib",
		'handle9' =>"sayakun wakil aleumla' maeak qrybana. aintazar min fadlik",
		'handle10' =>"edhrana , lm 'ahsul ealaa eamilik I D",
		'handle11' =>"sayakun ahd mumathili aleumla' maeak qrybana. aintazar min fadlik",
		'handle12' => 'almudakhalat alkhasat bik ghyr saliha',
		'handle_map1'=>"'iidha lm yakun ladayk tamdid , lidha yrja albaqa' ealaa alkhati litatasil bialmashghal alttali almatah",
		
		'handle_map'=>"edhrana , lm natamakan min aleuthur ealaa alraqm alddakhilii aldhy 'adkhalath , yrja almuhawalat maratan 'ukhraa biastikhdam raqm dakhiliin salih",
		'handle_map2'=>"yrja 'iidkhal alraqm alddakhilii maratan 'ukhraa",
		
		'customer_id_login1'=>'USER ID ni tsudzukete pondokī o nyūryoku shimasu',
		'customer_id_login2'=>"Mōshiwakearimasenga, yūzā ID o shutoku dekimasendeshita",
		'customer_id_login3'=>'CUSTOMER ID ga mukōdesu',
		'customer_id_login4'=>'CUSTOMER ID ni tsudzukete pondokī o sai nyūryoku shite kudasai',
		
		'user_id_login1'=>'Kojin no anshō bangō o nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
		'user_id_login2'=>"Mōshiwakearimasenga, himitsu no pin o shutoku dekimasendeshita.",
		'user_id_login4'=>'Nyūryoku shita yūzā ID ga mukōdesu.',	
		'user_id_login5'=>'USER I D o sai nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
		
		'pin_login1'=>'Mōshiwakearimasenga, akaunto ga burokkusareteimasu. Kasutamāsapōto ni go renraku kudasai. Arigatō',
		'pin_login2'=>'Okaerinasai',
		'pin_login3'=>'Akaunto no zandaka o kakunin suru ni wa, 1 o oshimasu',
		'pin_login4'=>'Onrain tensō rikuesuto no baai wa, 2 o oshimasu',
		'pin_login5'=>'4 O oshite, saigo no itsutsu no toranzakushon o kikimasu',
		'pin_login6'=>'5 O oshite akaunto no sutētasu o kakunin shimasu',
		'pin_login7'=>'liltahaquq min halat albitaqat , aidghata 6',
		'pin_login8'=>'Messēji o kiku ni wa, 3 o oshimasu',
		'pin_login10'=>'Anshō bangō o sai nyūryoku shite kara, pondokī o nyūryoku shite kudasai',
		'pin_login11'=>'Nyūryoku shita himitsu no pin ga mukōdesu',
		'pin_login12'=>'Anata ga motte iru ',
		'pin_login13'=>'Jushin torei no messēji.',
		
		'Welcome_user2'=>"Mōshiwakearimasenga, akaunto bangō o shutoku dekimasendeshita.",
		'Welcome_user3'=>'Akaunto bangō ni tsudzukete pondokī o nyūryoku shite kudasai.',
		
		'Welcome_user4'=>'Rōkaru tensō o okonau ni wa, 1 o oshimasu',
		'Welcome_user5'=>'Betsu no ginkō ni sōkin suru ni wa, 2 o oshimasu',
		'Welcome_user51'=>"li'iijra' tahwil 'iilaa hisab khasin , aidghata 3",
		'Welcome_user6'=>'Meinmenyū ni modoru ni wa, sutākī o oshimasu',
		
		'Welcome_user7'=>'Yoshin gendo-gaku ni tsuite wa, 1 o oshite kudasai',

		'Welcome_user8'=>'Kurejitto tensō no baai wa, 2 o oshimasu',
		'Welcome_user9'=>'Kurejittokādoakaunto o rinku suru ni wa, 3 o oshimasu',
		'Welcome_user10'=>"aintaqil 'iilaa alqayimat alrayiysiat aidghata ealaa miftah alnajma",
		'Welcome_user11'=>'Subete no messēji o sakujo suru ni wa, o oshimasu2',
		'Welcome_user12'=>'Nyūryoku ga mukōdesu. Yūkōna nyūryoku o nyūryoku shite kudasai',
		'Welcome_user13'=>'Onrain de seikyū-sho ya sonohoka no tokubetsuna akaunto kinō o shiharau ni wa, 3 o oshimasu',

		'Welcome_user14'=>'Anata wa messēji bangō o kikimasu',
		'Welcome_user15'=>'Anata no sutētasu wa horyū-chūdesu',
		'Welcome_user16'=>'Anata no sutētasu wa shōnin-zumidesu',
		'Welcome_user17'=>'Anata no sutētasu wa ichiji teishi sa rete imasu',
		'Welcome_user18'=>'halatk mahzura',
		'accout_balance_login1'=>'Kono akaunto no kako 5-kai no torihiki no shōsai',
		'accout_balance_login2'=>'Toranzakushon o mōichido kiku ni wa, sutā o oshimasu. Mein no akauntomenyū ni modoru ni wa, 1 o oshimasu.',
		'accout_balance_login3'=>'Akaunto no taipu:',
		'accout_balance_login4'=>'Akaunto no zandaka wa',
		
		'accout_balance_login5'=>'Akaunto no zandaka o mōichido kiku ni wa, sutā o oshimasu. Mein no akauntomenyū ni modoru ni wa, 1 o oshimasu',
		'accout_balance_lo gin6'=>'Nyūryoku shita kōza bangō ga mukōdesu',
		'accout_balance_login7'=>'Akaunto bangō o sai nyūryoku shite kudasai',

		'accout_balance_login8'=>'Mukōna nyūryoku o nyūryoku shimashita',
		'transfer_type1'=>"yrja mulahazatan 'anah li'asbab 'amniat , yumkinuk faqat altahwil 'iilaa hisab mrtbt mahfwz. mutatabiqat mae nfs aleamala",
		'transfer_type2'=>"Genzai, rinku sa reta `rōkaruakaunto' wa hozon sa rete imasen. Moyori no shiten ni akusesu shite akaunto o rinku shi, rōkaru tensō o okonatte kudasai.",  
		'transfer_type3'=>"litahdid hisab li'iijra' altahwil , aidghata ealaa miftah alnajma",

		'credit_process1'=>'rasid hisab alaitman alkhasu bik hu',
		'credit_process2'=>'lamazid min aleamaliat yrja alaikhtiar min alqayimat alrayiysiat',
		'credit_process3'=>'lays ladayk hisab aytiman murtabit.',
		'credit_process4'=>"lirbat hisab alaytiman alkhasi bik alraja' alaikhtiar min alqayimat alrayiysiat.",
		'credit_process5'=>"min ajl 'iijra' tahwil , yjb rabt bitaqat alaitiman , lilaistimae 'iilaa albitaqat almurtabitat almutahat , aidghata 1",
		'credit_process6'=>"litalaqiy altalab ean tariq albarid aidghat 1 , litalaqiy altalab ean tariq albarid al'iiliktrunii aidghat 2",

		'credit_process01'=>'ladayk albitaqat alttaliat murtabitat ,',
		'credit_process02'=>'ladayk',
		'credit_process03'=>"alraja' 'iidkhal akhar 6 'arqam fi bitaqat alaitiman",
		'credit_process04'=>"hisab albitaqat hdha yantami 'iilaa",
		'credit_process05'=>'alraja iidkhal almablagh',
		'credit_process06'=>'laqad dafaeat',
	    'credit_process07'=>"hadhih almaelumat alty tama 'iidkhaluha ghyr sahihat , yrja 'iieadat 'iidkhal alstt 'arqam",
		'credit_process07'=>'alraja iidkhal alramz',
		'credit_process08'=>"tama bad' altahwil alkhasi bik. aimnah min 12 'iilaa 24 saeatan li'iikmaliha",

		'credit_process001'=>"almablagh 'akbar min almablagh almutabaqii , yrja 'iieadat 'iidkhal almablagh aljadid",
		'credit_process002'=>"tama 'iirsal namudhaj altalab 'iilaa aleunwan almawjud fi almilafi shkrana lak",
 	  'credit_process003'=>"albarid al'iiliktruniu la yaemal",
 	  'credit_process004'=>"tama 'iirsal namudhaj altalab 'iilaa eunwan albarid al'iiliktrunii almawjud fi almilafi shkrana lak",

 	  'transfer_acc_amount1'=>"tafasil alhisab almusajilat tantami 'iilaa", 
 	  'transfer_acc_amount2'=>'alraja iidkhal almablagh almurad tahwilh mtbweana bimuftah aljanih.',
 	  'transfer_acc_amount3'=>"raqm altawjih aldhy 'adkhalath ghyr salihin.",
 	 'transfer_acc_amount4'=>"alraja' 'iieadat 'iidkhal raqm altawjih , mtbweana bimiftah aljunayh",
 	  'transfer_token1'=>'almablagh almaqbul',
 	  'transfer_token2'=>'laqad talabat tahwil mablagh',
 	 'transfer_token4'=>'almablagh ghyr maqbul laeadam kifayat alrasid',
 	 'transfer_token5'=>"alraja' 'iidkhal mablagh salih mtbweana bimiftah aljunayh",
 	  'transfer_token6'=>"raqm alhisab ghyr sahih yrja 'iieadat 'iidkhal raqm alhisab",
 	  'transfer_link_acc1'=>'hisabatik almurtabitat almusjilat hi',  
 	  
 	   'transfer_link_accb'=>'hisabat almustafid almusajalat alkhasat bik hi ', //newadded
 	 'transfer_typeb'=>'yurjaa mulahazat anah li asbab amniat , la yumkinuk altahwil iilaa iilaa hisabat almustafid almahfuza ', //newadded
 	 'transfer_link_accb1'=>'liaikhtiar raqm almustafid hadha ',//newadded

 	   'transfer_link_acc2'=>'liaikhtiar tahwil min raqm alhisab',  
 	   'transfer_link_acc3'=>'sahafa',  
 	   'transfer_link_acc4'=>"alraja' 'iidkhal raqm hisab almustafid mtbweana bimiftah aljunayh.",
 	   'transfer_link_acc5'=>"liaikhtiar raqm altahwil 'iilaa alhisab",  
 	   'transfer_link_acc6'=>'raqm hisab almustafid ghayr salih', 
 	   'transfer_link_acc7'=>'tama taeliq almustakhdam almustafid',
 	    'transfer_link_acc8'=>"lm yatima almuafaqat ealaa almustakhdam almustafid baed.",  
 	    'transfer_link_acc9'=>'eumlat hisab almustafid la tatatabaq mae eumlat hisab alkhasm', 
 	    'transfer_link_acc10'=>"min fadlik 'udkhil", 
 	    'transfer_link_acc11'=>'adkhalat ghayr salih', 
		'transfer_link_acc12'=>"yrja mulahazatan 'ana alkhasm lilrusum hu 0.002% min kuli eamaliat tahwil", 
 		
		'transfer_link_acc13'=>'nahn nakhtar raqm alhisab alkhasi bik lirusum alkhasm , yurjaa aldaght ealaa 1 lileadi', // newadded

 	 
 	 'transfer_acc_sort1'=>"'udkhul raqm altawjih mtbweana bimiftah aljunayh",
 	 'transfer_acc_sort2'=>"edhrana , lm 'ahsul ealaa raqm altawjih.",
 	  'transfer_acc_sort3'=>"raqm alhisab hdha ghyr mrtbt bialtahwil.",
 	  'transfer_acc_sort4'=>'alraja iieadat iidkhal raqm alhisab almurtabit almusajil , mtbweana bimiftah aljunayh',		
 	  'transfer_credit1'=>"lileawdat iilaa alqayimat alrayiysiat , aidghata ealaa 1",
	 'transfer_credit2'=>"lilkhuruj , yrja qate alaitisal. shukraan jazilana.",
	  'transfer_credit3'=>", tama qabul talab altahwil alkhasi bik iilaa ",
	  'transfer_credit4'=>"sayatimu khasm mablagh min hisabik.",
	  'transfer_credit5'=>"rasid hisabik aljadid hu",
	   'transfer_credit6'=>"yurja alsamah bihawali yawm iilaa yawmayn eamal hataa yatim tafeil altahwil bialkamil.",
	   'transfer_credit7'=>"laqad adkhalat ramz tahwil ghyr salh",
	   'transfer_credit8'=>"alraja' 'iidkhal rmaz ramz alnaql alsuri almukawan min 5 arqam mtbweana bimuftah aljanih",
 
	   'transfer_credit9'=>"edhrana , lm ahsul ealaa ramz altahwil almumiz",
		'dontGetResponse' => "asif , lm yasluni raduk",
		'ExceedLimit' => "laqad tajawazat hadu almuhlat alkhasat bik. wadaeaan."
		];
		
		return $Array[$language][$index];
		
	}
   
}
