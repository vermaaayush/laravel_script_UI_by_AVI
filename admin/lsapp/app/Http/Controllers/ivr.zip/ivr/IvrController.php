<?php

namespace App\Http\Controllers\ivr;

use App\Http\Controllers\Controller;
use DB;
use Session;
use Illuminate\Http\Request;
use Twilio\Rest\Client;
use Twilio\TwiML\VoiceResponse;
use Mail;
use App\Config;
use App\Ivr_message;
use App\ivr_purchase_numbers;
use App\Ivr_Support_number;
use App\CallLog;
use App\BaAccountHolders;
use App\BaUserAccounts;
use App\Ivr_Msg;
use App\BaTransactions;
use App\Http\Controllers\ivr\IvrLanguageController;


class IvrController extends Controller
{
	
	public function index(Request $request){
		
		$response = new VoiceResponse();	
		$input = $request->all();
			
		$dataArray['callerid']     = $input['CallSid'];
		$dataArray['accountid']    = $input['AccountSid'];
		$dataArray['callfrom']     = $input['From'];
		$dataArray['callto']       = $input['To'];
		$dataArray['callstatus']   = $input['CallStatus'];
		$dataArray['apiversion']   = $input['ApiVersion'];
		$dataArray['direction']    = $input['Direction'];
		$dataArray['fromcity']     = $input['FromCity'];
		$dataArray['fromstate']    = $input['FromState'];
		$dataArray['fromzip']      = $input['FromZip'];
		$dataArray['fromcountry']  = $input['FromCountry'];
		$dataArray['tocity']       = $input['ToCity'];
		$dataArray['tostate']      = $input['ToState'];
		$dataArray['tozip']        = $input['ToZip'];
		$dataArray['tocountry']    = $input['ToCountry'];
		
		CallLog::create($dataArray);
		
		$Settings       = Config::get();
	    $ivrs       = Config::get();
		$ivr_url = $ivrs[0]->ivr_url;
		 
	    $language       = $Settings[0]['ivr_lang'];
		$languages      = explode(',',$language);
		
		
		$response->say('Welcome to '.$Settings[0]['bank_name'], ['voice' => 'alice','language' => 'en-US']);
		for ($i=1; $i<=3; $i++) {
			
			$gather = $response->gather(['action' => $ivr_url.'/handle-language-input', 'method' => 'GET']);
			
			foreach($languages as $lang){
				
				if($lang=='ENGLISH'){
								
					$gather->say('If you want to listen in English,  Please Press 1', ['voice' => 'alice','language' => 'en']);					
					
				}
				if($lang=='ARABIC'){
					
					$gather->say('iidha kunt turid altahaduth biallughat alearabiat , aidghata 2', ['voice' => 'alice','language' => 'ar']);
					
				}
				if($lang=='SPANISH'){
					
					$gather->say('Si desea hablar en español, presione 3', ['voice' => 'alice','language' => 'es']);
					
				}
				if($lang=='PORTUGUESE'){
					
					$gather->say('Se você quiser falar em PORTUGUÊS, pressione 4', ['voice' => 'alice','language' => 'pt']);
					
				}
				if($lang=='JAPANESE'){
					
					$gather->say('Nihongo de hanashitai baai wa, 5 o oshite kudasai', ['voice' => 'alice','language' => 'ja-JP']);
					
				}
				if($lang=='GERMAN'){
					
					$gather->say('Wenn Sie auf DEUTSCH sprechen möchten, drücken Sie  6', ['voice' => 'alice','language' => 'de-DE']);
					
				}
				if($lang=='FRENCH'){
					
					$gather->say('Si vous voulez parler en FRANÇAIS, appuyez sur 7', ['voice' => 'alice','language' => 'fr-FR']);
					
				}						
			}
		}
		
		$response->say("Sorry, I didn't get your response");
		
		echo $response;
		
	}
	
	public function handle_language_input(Request $request){
		
		$response 		    = new VoiceResponse();	
		$LanguageController = new IvrLanguageController();
		$input 			    = $request->all();	
		$ivrs       = Config::get();
		$ivr_url = $ivrs[0]->ivr_url;

		$selectedOption    = $input['Digits'];
		if($selectedOption == 1){ $language = 'en'; }
		else if($selectedOption == 2){ $language = 'ar'; }
		else if($selectedOption == 3){ $language = 'es'; }
		else if($selectedOption == 4){ $language = 'pt'; }
		else if($selectedOption == 5){ $language = 'ja-JP'; }
		else if($selectedOption == 6){ $language = 'de-DE'; }
		else if($selectedOption == 7){ $language = 'fr-FR'; }
		else{ $language = 'en-US'; }
				
		for ($i=1; $i<=3; $i++) {
			
			$gather = $response->gather(['action' => $ivr_url.'/handle-input/'.$language, 'method' => 'GET','finishOnKey'=>'#']);
			$gather->say($LanguageController->index($language,'handle1'), ['voice' => 'alice','language' => $language]);
			$gather->say($LanguageController->index($language,'handle2'), ['voice' => 'alice','language' => $language]);
			$response->say($LanguageController->index($language,'dontGetResponse'), ['voice' => 'alice','language' => $language]);	
		}
		$response->say($LanguageController->index($language,'ExceedLimit'), ['voice' => 'alice','language' => $language]);
		$response->hangup();
		
		echo $response;
	
	}
	
	public function handle_input($language,Request $request){
		
		$response 		    = new VoiceResponse();	
		$LanguageController = new IvrLanguageController();
		$Settings            = Config::get();
		$input 			    = $request->all();	
        $selectedOption     = $input['Digits'];
        $ivrs       = Config::get();
        $ivr_url = $ivrs[0]->ivr_url;
        
		if($selectedOption == 1){
			for ($i=1; $i<=3; $i++) {
				
				$gather = $response->gather(['action' => $ivr_url.'/customerID-login/'.$language, 'method' => 'GET','finishOnKey'=>'#']);
				$gather->say($LanguageController->index($language,'handle3'), ['voice' => 'alice','language' => $language]);
				$response->say($LanguageController->index($language,'dontGetResponse'), ['voice' => 'alice','language' => $language]);	
			}
			$response->say($LanguageController->index($language,'ExceedLimit'), ['voice' => 'alice','language' => $language]);
			$response->hangup();
		}elseif($selectedOption == 2){

				$response->say($LanguageController->index($language,'handle4'), ['voice' => 'alice','language' => $language]);			
				$gather = $response->gather(['action' => $ivr_url.'/handle-input-mapped/'.$language, 'method' => 'GET','finishOnKey'=>'#','numDigits'=>4]);
				$gather->say($LanguageController->index($language,'handle5').$Settings[0]['bank_name'], ['voice' => 'alice','language' => $language]);
				$gather->say($LanguageController->index($language,'handle6'), ['voice' => 'alice','language' => $language]);
				
				if($Settings[0]['admin_support_phone']!=''){
												
					$response->say($LanguageController->index($language,'handle7'), ['voice' => 'alice','language' => $language]);
					$response->say($LanguageController->index($language,'handle8'), ['voice' => 'alice','language' => $language]);
					$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);
				//	$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
				//	$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');		
					$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);		
					$response->dial($Settings[0]['admin_support_phone']);
				}else{
					$response->say($LanguageController->index($language,'ExceedLimit'), ['voice' => 'alice','language' => $language]);
				}
				$response->hangup();
			
		}else{
					
				$this->handle_not_get_response($language,$response);	
		}
		
		echo $response;
		exit;
	
	}
	   	
   	public function handle_input_mapped($language,Request $request){
		
		$response 		    = new VoiceResponse();	
		$LanguageController = new IvrLanguageController();
		$input 			    = $request->all();	
		$selectedOption     = $input['Digits'];
		$SupportNumbers     = Ivr_Support_number::where('ext_number',$selectedOption)->get();
		 $ivrs       = Config::get();
        $ivr_url = $ivrs[0]->ivr_url;

		
		if($SupportNumbers->count()){
	
			$response->say($LanguageController->index($language,'handle8'), ['voice' => 'alice','language' => $language]);
			$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);
		//	$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
		//	$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
			$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);			
			$response->dial($SupportNumbers[0]['support_number']);
			$response->hangup();				
		}else{
			
			$response->say($LanguageController->index($language,'handle_map'), ['voice' => 'alice','language' => $language]);
			for ($i=1; $i<=2; $i++) {
				
				$gather = $response->gather(['action' => $ivr_url.'/handle-input-mapped-1/'.$language, 'method' => 'GET','finishOnKey'=>'#']);
				$gather->say($LanguageController->index($language,'handle_map2'), ['voice' => 'alice','language' => $language]);
				$response->say($LanguageController->index($language,'dontGetResponse'), ['voice' => 'alice','language' => $language]);
			}
			$response->say($LanguageController->index($language,'ExceedLimit'), ['voice' => 'alice','language' => $language]);	
			$response->hangup();	
		}
		echo $response;
		exit;
		
	}
	
	public function handle_input_mapped_1($language,Request $request){
		
		$response 		    = new VoiceResponse();	
		$LanguageController = new IvrLanguageController();
		$input 			    = $request->all();	
		$selectedOption     = $input['Digits'];
		$SupportNumbers     = Ivr_Support_number::where('ext_number',$selectedOption)->get();
		$Settings           = Config::get();

		
		if($SupportNumbers->count()){
	
			$response->say($LanguageController->index($language,'handle8'), ['voice' => 'alice','language' => $language]);
			$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);
			$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
			$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
			$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);			
			$response->dial($SupportNumbers[0]['support_number']);
			$response->hangup();				
		}else{
			
			if($Settings[0]['admin_support_phone']!=''){
												
				$response->say($LanguageController->index($language,'handle7'), ['voice' => 'alice','language' => $language]);
				$response->say($LanguageController->index($language,'handle8'), ['voice' => 'alice','language' => $language]);
				$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);
				$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
				$response->play('https://dubaiallier.ae/tele/ivr/includes/pp.wav');	
				$response->say($LanguageController->index($language,'handle9'), ['voice' => 'alice','language' => $language]);			
				$response->dial($Settings[0]['admin_support_phone']);
			}else{
				$response->say($LanguageController->index($language,'ExceedLimit'), ['voice' => 'alice','language' => $language]);
			}
			$response->hangup();
		}
		echo $response;
		exit;
		
	}
	
	public function handle_not_get_response($language,$response){
		
		$ivrs       = Config::get();
        $ivr_url = $ivrs[0]->ivr_url;
        
		$gather = $response->gather(['action' => $ivr_url.'/handle-input', 'method' => 'GET','finishOnKey'=>'#']);
		$gather->say($LanguageController->index($language,'invalidInput'), ['voice' => 'alice','language' => $language]);
		$gather->say($LanguageController->index($language,'handle1'), ['voice' => 'alice','language' => $language]);
		$gather->say($LanguageController->index($language,'handle2'), ['voice' => 'alice','language' => $language]);
		echo $response;
		exit;
		
	}
 
	public function ivr_status(Request $request){
	    
	    $input 			    = $request->all();
		
		$dataArray['callerid']     = $input['CallSid'];
		$dataArray['accountid']    = $input['AccountSid'];
		$dataArray['callfrom']     = $input['From'];
		$dataArray['callto']       = $input['To'];
		$dataArray['callstatus']   = $input['CallStatus'];
		$dataArray['apiversion']   = $input['ApiVersion'];
		$dataArray['direction']    = $input['Direction'];
		$dataArray['fromcity']     = $input['FromCity'];
		$dataArray['fromstate']    = $input['FromState'];
		$dataArray['fromzip']      = $input['FromZip'];
		$dataArray['fromcountry']  = $input['FromCountry'];
		$dataArray['tocity']       = $input['ToCity'];
		$dataArray['tostate']      = $input['ToState'];
		$dataArray['tozip']        = $input['ToZip'];
		$dataArray['tocountry']    = $input['ToCountry'];
		

		CallLog::where('callerid',$input['CallSid'])->update($dataArray);
		
		echo 'done'; exit;
	}
		
	public function ivr_fail(Request $request){
		
		$response 		    = new VoiceResponse();	
		$response->say('Sorry for any inconvenience, system temporarily down for maintenance reason please try again after some time. Thank you', ['voice' => 'alice','language' =>'en-US']);
		echo $response;
		exit;
		
	}

		
}